﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Mathe_IDAF_Luca_Bisanti
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void TextBoxA(object sender, TextChangedEventArgs e)
    {

    }

    private void TextBoxB(object sender, TextChangedEventArgs e)
    {

    }

    private void TextBoxC(object sender, TextChangedEventArgs e)
    {

    }

    private void Button_Click(object sender, RoutedEventArgs e)
    {

      bool error = false;

      double a;
      if (!double.TryParse(textBoxA.Text, out a))
        error = true;
      double b;
      if (!double.TryParse(textBoxB.Text, out b))
        error = true;
      double c;
      if (!double.TryParse(textBoxC.Text, out c))
        error = true;

      // Berechne x-Wert des Scheitelpunkts
      double xs = -b / (2 * a);

      // Berechne y-Wert des Scheitelpunkts
      double ys = c - ((b * b) / (4 * a));

      double diskriminante = b * b - 4 * a * c;

      if (diskriminante > 0 && error == false)
      {
        double x1 = (-b + Math.Sqrt(diskriminante)) / (2 * a);
        double x2 = (-b - Math.Sqrt(diskriminante)) / (2 * a);
        MessageBox.Show("Es gibt zwei Lösungen! : x1 = " + x1 + " und x2 = " + x2 + "\n\nScheitelpunkt: (" + xs + ";" + ys + ")");
      }
      else if (diskriminante == 0 && error == false)
      {
        double x = -b / (2 * a);
        MessageBox.Show("Es gibt eine Doppellösung! : x = " + x + "\n\nScheitelpunkt: (" + xs + ";" + ys + ")");
      }
      else if (diskriminante < 0 && error == false )
      {
        MessageBox.Show("Es gibt keine Lösung!" + "\n\nScheitelpunkt: (" + xs + ";" + ys + ")");
      }

      if (error == true)
      {
        MessageBox.Show("Error\nSie müssen die Zahlen richtig angeben!");
        error = false;
      }
    }
  }
}
